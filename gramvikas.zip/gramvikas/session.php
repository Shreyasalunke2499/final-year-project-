<?php
include('conn_db.php');
session_start();
$user_check=$_SESSION['login_user'];

// $result = mysqli_query($conn,"select * from registration where EmpName= 'akash' ");
// // echo $result;
// $num_rows = mysqli_num_rows($result);


// $user_check = 'akash';
$ses_sql=mysqli_query($conn,"select EmpName,email from registration where email='$user_check'");
$row=mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
$loggedin_session=$row['email'];
$loggedin_id=$row['EmpName'];
if(!isset($loggedin_session) || $loggedin_session==NULL) {
	echo "Go back";
	header("Location: reg.php");
}
?>