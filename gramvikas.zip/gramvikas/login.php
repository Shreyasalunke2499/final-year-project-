<?php
// include("login_back.php");
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login to Gram-Vikas Yojna</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


</head>
<style>
  .header {
    box-sizing: border-box;
    border: 1px solid rgb(38, 122, 39);
    background-color: rgb(68, 182, 56);
    text-align: center;
    margin-top: 3px;
  }

  .yojna-name {
    display: flex;
    margin-left: 20px;
    margin-top: 5px;
  }

  .yojna-name h2 {
    padding: 10px;
  }

  .yojna-name ul {
    text-align: center;
  }

  .header img {
    width: 60px;
    height: 60px;
    margin: 5px;
  }

  .navbar {
    height: 60px;
    width: 400px;
    text-align: center;
    box-sizing: border-box;
    margin-left: 200px;
    background-color: rgb(62, 146, 56);
  }

  .nav {
    list-style: none;
    margin-bottom: 5px;
  }

  .nav-link {
    color: white;
    text-decoration: none;
    font-size: 22px;
    margin-bottom: 10px;
  }

  body#LoginForm {
    background-image: url("https://hdwallsource.com/img/2014/9/blur-26347-27038-hd-wallpapers.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    padding: 10px;
  }

  .form-heading {
    color: #fff;
    font-size: 23px;
  }

  .panel h2 {
    color: #444444;
    font-size: 18px;
    margin: 0 0 10px 0;
    margin-top: 0%;
  }

  .panel h1 {
    border: 1px solid rgb(250, 171, 193);
    background-color: rgb(252, 206, 214);
    border-radius: 20px;
    font-size: 32px;
    padding: 5px;
  }

  .panel p {
    color: #777777;
    font-size: 16px;
    margin-top: 5px;
    margin-bottom: 30px;
    line-height: 24px;
  }

  .login-form .form-control {
    background: #f7f7f7 none repeat scroll 0 0;
    border: 1px solid #d4d4d4;
    border-radius: 4px;
    font-size: 16px;
    height: 50px;
    line-height: 50px;
  }

  .main-div {
    background: #ffffff none repeat scroll 0 0;
    border-radius: 2px;
    margin: 10px auto 30px;
    max-width: 38%;
    padding: 0;
  }

  .login-form .form-group {
    margin-bottom: 10px;
  }

  .login-form {
    text-align: center;
  }

  .forgot a {
    color: #777777;
    font-size: 18px;
    text-decoration: underline;
  }

  .login-form .btn.btn-primary {
    background: #f0ad4e none repeat scroll 0 0;
    border-color: #f0ad4e;
    color: #ffffff;
    font-size: 20px;
    width: 100%;
    height: 50px;
    line-height: 50px;
    padding: 0;
    border-radius: 15px;
  }

  .forgot {
    text-align: left;
    margin-bottom: 30px;
  }

  .botto-text {
    color: #ffffff;
    font-size: 14px;
    margin: auto;
  }

  .login-form .btn.btn-primary.reset {
    background: #f077ad none repeat scroll 0 0;
  }

  .back {
    text-align: left;
    margin-top: 10px;
  }

  .back a {
    color: #444444;
    font-size: 13px;
    text-decoration: none;
  }

  #Login button {
    font-size: 24px;
    width: 150px;
    border-radius: 22px;
    background-color: rgb(252, 206, 214);
    color: black;
  }

  .footer {
    margin: 5px;
    margin-top: 100px;
  }
</style>

<body>
  <header class="header">
    <div class="yojna-name">
      <img src="./img/logo1.png" alt="Logo">
      <h2 style="font-family: 'Times New Roman', Times, serif;">Gram Vikas Yojna</h2>

      <div class="navbar">
        <section class="nav">
          <a class="nav-link" href="#"></a>
          <a class="nav-link active" aria-current="page" href="./welcome.php">Home</a>
          <a class="nav-link" href="#"></a>
          <a class="nav-link" href="./welcome.php">About Us</a>
        </section>
      </div>
    </div>
  </header>
  <div>
    <div class="container">
      <h1 class="form-heading">login Form</h1>
      <div class="login-form">
        <div class="main-div">
          <div class="panel">
            <h1 style="font-family: 'Times New Roman', Times, serif;">User Login</h2>
              <p>Please enter your email and password</p>
          </div>
          <form action="./logincheck.php" method="POST">

            <div class="form-group">


              <input type="email" name="email" class="form-control" id="email" placeholder="Enter Email Address">

            </div>

            <div class="form-group">

              <input type="password" name="password" required class="form-control" id="password" placeholder="Enter Password">

            </div>
            <div class="forgot">
              <a href="reset.html">Forgot password?</a>
            </div>
            <input type="submit"  id="submit" required class="btn btn-primary">

          </form>
        </div>
      </div>
    </div>
  </div>
  </div>
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <div class="copyright">
            <p>© <span>2022</span> <a href="#" class="transition">@Vaishnavi</a> All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--
  <script>
    $("#submit").click(function() {
      var email = $("#email").val();
      var password = $("#password").val();

      if (email == '' && password == '') {
        swal({
          title: "Fields Empty",
          text: "Please, check the missing field..!",
          icon: "warning",
          button: "Ok",
        });
      } else {
        swal({
          title: "Successfully Login..!",
          icon: "success",
          button: "Ok",
        });
      }
    });
  </script>
  -->
</body>

</html>