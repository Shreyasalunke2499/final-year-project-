<?php

$ename = $_GET['EmpName'];
$em = $_GET['email'];
$pass = $_GET['password'];
$repass = $_GET['repassword'];
$addr = $_GET['address'];
$c = $_GET['city'];
$s = $_GET['state'];
$count = $_GET['country'];
$pi = $_GET['pin'];



$host = "localhost";
$username = "root";
$password = "";
$db_name = "project";

$conn = mysqli_connect($host, $username, $password, $db_name);

if ($pass == $repass) {
    $query = "insert into registration values ('$ename','$em','$pass','$repass', '$addr', '$c','$s', '$count', '$pi')";
    $data = mysqli_query($conn, $query);
    header("location: login.php");
}
else{
    echo "Password Not Matched...";
}


// if($data){
//   echo '<script>alert("Data inserted successfully !")</script>';
// }
// else{
//   echo '<script>alert("All fields are required")</script>';
// }
