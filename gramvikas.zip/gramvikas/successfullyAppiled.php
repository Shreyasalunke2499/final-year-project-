<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Successfully Applied</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style>
        .container{
            align-items: center;
            text-align: center;
           margin-top: 10%;
           margin-left: 30%;
        }
        .box{
            box-sizing: border-box;
            border: 1px solid black;
            width: 500px;
            height: 250px;
           background-color: rgb(251, 251, 251);
        }
        .box img{
            height: 80px;
            width: 80px;
            border-radius: 50%;
            margin-top: -50px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);

        }
        .btn{
            width: 130px;
            font-size: 20px;
            padding: 7px;
            cursor: pointer;
            border-radius: 10px;
            margin-top: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="box">
            <img src="./img/tick.jpeg" alt="">
            <h2 style="margin-top: 10px;">Successfully Applied..!</h2>
            <h6 style="margin-top: 30px;">Download pdf for applied scheme.</h6>
            <button type="submit" style="margin-top: 20px;" class="btn btn-primary">Download</button>

        </div>
    </div>
</body>
</html>