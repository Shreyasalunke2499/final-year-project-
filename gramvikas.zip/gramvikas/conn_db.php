<?php

$host= "localhost";
$username= "root";
$password = "";

$db_name = "project";

$conn = mysqli_connect($host, $username, $password, $db_name);


?>