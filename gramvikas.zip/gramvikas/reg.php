<?php
include("conn_db.php");
error_reporting(0);
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <title>Registration Page</title>
</head>


<style>
  .header {
    box-sizing: border-box;
    border: 1px solid rgb(38, 122, 39);
    background-color: rgb(68, 182, 56);
    text-align: center;
    margin-top: 3px;
  }

  .yojna-name {
    display: flex;
    margin-left: 20px;
    margin-top: 5px;
  }

  .yojna-name h2 {
    padding: 10px;
  }

  .yojna-name ul {
    text-align: center;
  }

  .header img {
    width: 60px;
    height: 60px;
    margin: 5px;
  }

  .navbar {
    height: 60px;
    width: 400px;
    text-align: center;
    box-sizing: border-box;
    margin-left: 200px;
    background-color: rgb(62, 146, 56);
  }

  .nav {
    list-style: none;
    margin-bottom: 5px;
  }

  .nav-link {
    color: white;
    text-decoration: none;
    font-size: 22px;
    margin-bottom: 10px;
  }

  .registration {
    justify-content: center;
    text-align: center;
    border: 1px solid rgb(250, 171, 193);
    background-color: rgb(252, 206, 214);
    border-radius: 20px;
    padding: 5px;
  }

  .formm label {
    font-size: 18px;
  }

  .center {
    text-align: center;
  }
</style>

<body>
  <header class="header">
    <div class="yojna-name">
      <img src="./img/logo1.png" alt="Logo">
      <h2 style="font-family: 'Times New Roman', Times, serif;">Gram Vikas Yojna</h2>

      <div class="navbar">
        <section class="nav">
          <a class="nav-link" href="#"></a>
          <a class="nav-link active" aria-current="page" href="./welcome.php">Home</a>
          <a class="nav-link" href="#"></a>
          <a class="nav-link" href="./welcome.php">About Us</a>
        </section>
      </div>
    </div>
  </header>
  <div class="container mt-4">
    <div class="registration">
      <h3>Please Register Here</h3>
    </div>
    <hr>
    <div class="formm">
      <form action="./reg_back.php" method="GET">
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Employee Name :</label>
            <input type="text" class="form-control" name="EmpName" id="EmpName" placeholder="EmpName">
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Email : </label>
            <input type="text" class="form-control" required name="email" id="username" placeholder="Email">
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Password : </label>
            <input type="password" class="form-control" required name="password" id="password" placeholder="Password">
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Confirm Password : </label>
            <input type="password" class="form-control" required name="repassword" id="inputPassword4" placeholder="Password">
          </div>
        </div>

        <div class="form-group">
          <label for="inputAddress2">Address : </label>
          <input type="text" class="form-control" required name="address" id="inputAddress2" placeholder="Apartment or floor">
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputCity">City : </label>
            <input type="text" class="form-control" required name="city" id="inputCity">
          </div>
          <div class="form-group col-md-6">
            <label for="inputState">State : </label>
            <input type="text" class="form-control" required name="state" id="state">
          </div>
          <div class="form-group col-md-6">
            <label for="inputCountry">Country : </label>
            <input type="text" class="form-control" required name="country" id="country">
          </div>
          <div class="form-group col-md-2">
            <label for="inputPin">Pin : </label>
            <input type="text" class="form-control" required name="pin" id="inputPin">
          </div>
        </div>
        <div class="center">
          <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="gridCheck">
              <label class="form-check-label" for="gridCheck">
                Remember Me
              </label>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Sign in</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>


<?php
// echo "hi0";

// $ename=$_GET['EmpName'];
// $em= $_GET['email'];
// $pass= $_GET['password'];
// $repass= $_GET['repassword'];
// $addr= $_GET['address'];
// $c=$_GET['city'];
// // $s= $_GET['state'];
// $count=$_GET['country'];
// $pi= $_GET['pin'];

// $query = "insert into registration  values ('$ename','$em','$pass','$repass', '$addr', '$c', '$count', '$pi')";
// $data = mysqli_query($conn , $query);

// echo $ename;
// echo $em;
// echo $pass;
// echo $repass;
// echo $addr;
// echo $c;
// echo $count;
// echo $pi;
// if($data){
//  echo '<script>alert("Data inserted successfully !")</script>';
// }
// else{
//   echo '<script>alert("All fields are required")</script>';
// }

?>