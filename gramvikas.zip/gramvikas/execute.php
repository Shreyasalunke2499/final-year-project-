<?php 
session_start();
include('conn_db.php');
$email=$_POST['email'];
$result = mysqli_query($con,"SELECT * FROM registration WHERE email='$email'");
$num_rows = mysqli_num_rows($result);
if ($num_rows) {
    header("location: reg.php?remarks=failed"); 
   }
   else {
    $ename=$_GET['EmpName'];
    $em= $_GET['email'];
    $pass= $_GET['password'];
    $repass= $_GET['repassword'];
    $addr= $_GET['address'];
    $c=$_GET['city'];
    $s= $_GET['state'];
    $count=$_GET['country'];
    $pi= $_GET['pin'];
    if(mysqli_query($con,"insert into registration values ('$ename','$em','$pass','$repass', '$addr', '$c', '$s', '$count', '$pi')")){ 
	header("location: reg.php?remarks=success");
 }else{
	 $e=mysqli_error($con);
	header("location: reg.php?remarks=error&value=$e");	 
 }
}
?>