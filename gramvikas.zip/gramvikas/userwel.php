<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>

    <script src="https://kit.fontawesome.com/77d20cda2e.js" crossorigin="anonymous"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <!------ Include the above in your HEAD tag ---------->


    <style>
        *body {
            margin: 0%;
            font-family: 'open_sansregular', Arial, Helvetica, sans-serif;

        }

        .topStrip ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .leftLink {
            float: left;
            list-style: none;
        }

        .rightLink {
            float: right;
            list-style: none;
            display: list-item;
            display: flex;
        }

        .flag {
            height: 24;
            width: 35;
            margin-right: 5px;
        }

        .topStrip {
            padding: 20px 20px;
            box-sizing: border-box;
            font-size: 15px;
            background-color: rgb(235, 221, 247);
            height: 80px;
            border-top: 2px solid rgb(200, 151, 243);
            border-left: 3px solid rgb(200, 151, 243);
            border-right: 3px solid rgb(200, 151, 243);
            border-top-right-radius: 10px;
            border-top-left-radius: 10px;
        }

        .topStrip li {
            float: left;
            position: relative;
            font-size: 23px;
        }

        .textResizeWrapper {
            margin-right: 15px;
        }

        .search {
            margin-right: 5px;
            list-style: none;
        }

        .searchBlock {
            line-height: 30px;
            border-radius: 10px;
        }

        .anime {
            box-sizing: border-box;
            margin: 10px;
            background-color: rgb(250, 183, 236);
            height: 50px;
            border-left: 5px solid rgb(182, 67, 157);
            border-right: 5px solid rgb(182, 67, 157);
            border-radius: 7px;
        }

        .anime p {
            margin: 10px;
            font-size: 20px;
        }

        .alert {
            text-decoration: none;
            box-sizing: border-box;
            width: 300px;
            height: 170px;
            justify-content: center;
            text-align: center;
            background-color: rgb(248, 227, 227);
            border: 2px solid rgb(113, 40, 40);

        }

        .alert h4 {
            text-decoration: none;
            color: rgb(107, 37, 37);
            margin-top: 0%;
            padding: 5px;
        }

        .alert img {
            height: 90px;
            width: 270px;
            border-radius: 10px;
            padding: 10px;
        }

        .alert a {
            text-decoration: none;
        }

        .notice {
            box-sizing: border-box;
            width: 300px;
            margin: 10px;
            margin-right: 20px;
        }

        .panel {
            margin-top: 20px;
            height: 50px;
            border-radius: 10px;
            display: grid;
            grid-template-columns: 60px 150px;
            border: 2px solid rgb(134, 50, 50);
        }

        .panel img {
            height: 30px;
            width: 30px;
            margin-top: 7px;
        }

        .item1 {
            height: 48px;
            width: 90px;
            align-items: center;
            text-align: center;
            border-right: 2px solid brown;
        }

        .item2 {
            margin-top: 0px;
            height: 50px;
            width: 200px;
            align-items: center;
            text-align: center;
        }

        .box-link {
            border: 2px solid rgb(134, 50, 50);
            height: 90px;
            margin-top: 20px;
            border-radius: 10px;
            display: grid;
            grid-template-columns: 80px 150px;
        }

        .box-link img {
            height: 30px;
            width: 30px;
            margin-top: 7px;
        }

        .icon {
            height: 50px;
            width: 90px;
            align-items: center;
            text-align: center;
            border-right: 2px solid brown;
            border-bottom: 2px solid brown;
            border-top-left-radius: 5px;
        }

        .help1 {
            height: 50px;
            width: 185px;
            align-items: center;
            text-align: center;
            border-bottom: 2px solid brown;
        }

        .box2 {
            width: 300px;
            text-align: center;
            font-size: 20px;
        }

        .box2 a {
            text-decoration: none;
            color: black;
        }

        .middle-panel {
            box-sizing: border-box;
            width: 620px;
            border: 1px solid black;
            margin: 10px;
            position: relative;
        }

        .carousel-wrapper {
            height: 200px;
            position: relative;
            width: 620px;
            display: block;
            border: 2px solid black;
        }

        .carousel-item {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            opacity: 0;
            transition: all 0.5s ease-in-out;
        }

        .arrow {
            border: solid black;
            border-width: 0 3px 3px 0;
            display: inline-block;
            padding: 12px;
        }

        .arrow-prev {
            left: 10px;
            position: absolute;
            top: 50%;
            transform: translateY(-50%) rotate(135deg);

        }

        .arrow-next {
            right: 10px;
            position: absolute;
            top: 50%;
            transform: translateY(-50%) rotate(-45deg);
        }

        [id^="item"] {
            display: none;
        }

        .item-1 {
            z-index: 2;
            opacity: 1;
            background: url('./img/sbka-sath.jpg');
            background-size: cover;
        }

        .item-2 {
            background: url('./img/yojna-yadi.jpg');
            background-size: cover;
            box-sizing: border-box;
        }

        *:target~.item-1 {
            opacity: 0;
        }

        #item-1:target~.item-1 {
            opacity: 1;

        }

        #item-2:target~.item-2,
        #item-3:target~.item-3 {
            z-index: 3;
            opacity: 1;
        }

        .instruction {
            box-sizing: border-box;
            border: 1px solid black;
            height: 250px;
            width: 620px;
        }

        .instruction h2{
            background-color: rgb(248, 227, 227);
            padding: 5px;
        }
        .clickproceed {
            border: 1px solid black;
            background: rgb(253, 234, 234);
            width: 300px;
            border: 2px solid brown;
            border-radius: 5px;
            height: 60px;
            font-size: 16px;
            box-sizing: border-box;
            text-align: center;
            color: rgb(6, 6, 6);
            margin-top: 10px;
        }

        .box {
            margin-top: 25px;
            width: 300px;
            height: 300px;
        }

        .box div a {
            text-decoration: none;
            color: rgb(19, 18, 18);
            font-size: 21px;
            font-family: 'Times New Roman', Times, serif;

        }

        .boxes {
            box-sizing: border-box;
            height: 50px;
            text-align: center;
            padding: 7px;
            background-color: rgb(248, 229, 229);
            border: 2px solid rgb(175, 76, 76);
            border-radius: 10px;
            margin-top: 10px;
        }

        .boxes a {
            font-size: 24px;
        }

        .clickproceed label {
            font-size: 20px;
            font-weight: bold;
            margin: 4px;
        }

        .content-header {
            font-family: 'Oleo Script', cursive;
            color: #fcc500;
            font-size: 55px;
        }

        .section-content {
            text-align: center;

        }

        #contact {
            margin-top: 10px;
            font-family: 'Teko', sans-serif;
            padding-top: 30px;
            width: 100%;
            width: 100vw;
            height: 550px;
            background: #3a6186;
            /* fallback for old browsers */
            background: -webkit-linear-gradient(to left, #3a6186, #89253e);
            /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to left, #3a6186, #89253e);
            /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
            color: black;
        }

        .contact-section {
            padding-top: 40px;
        }

        .contact-section .col-md-6 {
            width: 50%;
        }

        .form-line {
            border-right: 1px solid #B29999;
        }

        .form-group {
            margin-top: 10px;
        }

        label {
            font-size: 20px;
            line-height: 1em;
            font-weight: normal;
        }

        .form-control {
            font-size: 16px;
            color: black;
        }

        textarea.form-control {
            height: 135px;
            /* margin-top: px;*/
        }

        .submit {
            float: right;
            width: 150px;
            background-color: transparent;
            color: #fff;
        }

        .section-content h3 {
            color: #fff;
            font-size: 26px;
            font-family: 'Times New Roman', Times, serif;
        }

        .about label {
            font-size: 18px;
        }

        .heading {
            height: 70px;
            width: 100%;
            background-color: rgb(36, 164, 36);
        }
        .myprofile{
           border-radius: 50px;
        }
    </style>
</head>

<body>
    <header>
        <div class="topStrip cf">
            <ul class="leftLink">
                <li class="govtIndia"><img class="flag"
                        src="https://swachhbharatmission.gov.in/SBMCMS/writereaddata/images/indianflag.jpg"
                        alt="India Flag" margin="5px" height="22" width="33" /></li>
                <li style="font-family: 'Times New Roman', Times, serif;">Government of India</li>
            </ul>
            <ul class="rightLink">
                <div id="accessControl" class="textResizeWrapper">
                    <input type="submit" name="ctl00$ContentPlaceHolder1$UserCMSHeader1$ChangeSiteStyle1$font_normal"
                        value="A-" onclick="return validate();"
                        id="ContentPlaceHolder1_UserCMSHeader1_ChangeSiteStyle1_font_normal" title="Decrease Font Size"
                        class="fontScaler normal font-normal" />

                    <input type="submit" name="ctl00$ContentPlaceHolder1$UserCMSHeader1$ChangeSiteStyle1$font_large"
                        value="A" onclick="return validate();"
                        id="ContentPlaceHolder1_UserCMSHeader1_ChangeSiteStyle1_font_large" title="Normal Font Size"
                        class="fontScaler current large font-large" />

                    <input type="submit" name="ctl00$ContentPlaceHolder1$UserCMSHeader1$ChangeSiteStyle1$font_larger"
                        value="A+" onclick="return validate();"
                        id="ContentPlaceHolder1_UserCMSHeader1_ChangeSiteStyle1_font_larger" title="Increase Font Size"
                        class="fontScaler largest font-largest" />
                </div>
                <a class="search" title="Search" href="#" id="searchToggle"><span>Search</span></a>
                <div id="ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_pnlKeywordSrch"
                    onkeypress="javascript:return WebForm_FireDefaultButton(event,ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_btnSearch)">

                    <div class="searchBox cf">
                        <div class="inputSearch">
                            <input name="ctl00$ContentPlaceHolder1$UserCMSHeader1$KeywordSearch1$txtKeyword" type="text"
                                id="ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_txtKeyword" title="Search"
                                class="searchInput ui-autocomplete-input" placeholder="Search" />

                            <input type="submit"
                                name="ctl00$ContentPlaceHolder1$UserCMSHeader1$KeywordSearch1$btnSearch" value="Go"
                                onclick="return CheckString();"
                                id="ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_btnSearch" title="Go"
                                class="searchSubmit" />
                        </div>
                    </div>
                </div>
                <script src="https://www.google.com/jsapi" type="text/javascript">
                </script>
                <noscript class="displayNone">
                </noscript>
                <script type="text/javascript">
                    function CheckString() {
                        var Key = document.getElementById('ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_txtKeyword');
                        if (Key.value.length < 3) {
                            Key.value = "Minimum 3 character required";
                            return false;
                        }
                        if (Key.value == Key.defaultValue) {
                            Key.value = "Enter valid search text";
                            return false;
                        }
                        if (Key.value == "Minimum 3 character required" || Key.value == "Enter valid search text") {
                            return false;
                        }
                        return true;
                    }
                    var hdnLanguageID = document.getElementById('ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_hdnLanguageID');
                    var searchKeyword = "";
                    $(function () {
                        $("#ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_txtKeyword").autocomplete({
                            source: function (request, response) {
                                //searchKeyword = escape(request.term);
                                searchKeyword = request.term.trim();
                                var pID;
                                var hdnSiteID = document.getElementById('ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_hdnSiteID');;
                                var hdnLanguageID = document.getElementById('ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_hdnLanguageID');
                                if (hdnSiteID.value == '') pID = 1;
                                else pID = hdnSiteID.value;
                                $.ajax({
                                    url: "AutoCompleteService.asmx/AutoSugessionSiteSearch",
                                    data: "{ 'SearchText': '" + escape(request.term) + "' , 'SiteId':'" + pID + "', 'LanguageId':'" + document.getElementById('ContentPlaceHolder1_UserCMSHeader1_KeywordSearch1_hdnLanguageID').value + "', 'TopRecords':'" + '10' + "' }",
                                    dataType: "json",
                                    type: "POST",
                                    contentType: "application/json; charset=utf-8",
                                    dataFilter: function (data) {
                                        return data;
                                    },
                                    success: function (data) {
                                        response($.map(data.d, function (item) {
                                            var label1 = item.split("::");
                                            return {
                                                value: label1[1] + "::" + label1[2],
                                                label: label1[0]
                                            }
                                        }))
                                    },
                                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                                        //  alert(textStatus);
                                    }
                                });
                            },
                            select: function (event, ui) {
                                $(event.target).val(ui.item.label);
                                var target = ui.item.value.split("::")
                                setSearchCookie();
                                if (target[1] == "_blank") {
                                    window.open(target[0], '_blank');
                                } else {
                                    //window.location = ui.item.value;
                                    window.location = target[0];
                                }
                                return false;
                            },
                            minLength: 3
                        });
                        /*  Auto Suggestion Script */
                        //-->
                    });

                    function setSearchCookie() {
                        //$.removeCookie("paramHighlight");
                        var date = new Date();
                        var minutes = 1;
                        date.setTime(date.getTime() + (minutes * 60 * 1000));
                        $.cookie("paramHighlight", searchKeyword, {
                            expires: date
                        });
                        //alert(searchKeyword.trim());
                    }
                </script>
            </ul>
        </div>
        </topStrip cf>
    </header>
    <div class="heading">
        <div class="logobar" >
            <h2 style="margin:0%; padding: 10px;">
                <img src="./img/logo1.png" alt="logo" height="50" width="50">
                Gram-Vikas Yojna
                <span style="font-size: 22px; padding: 5px; margin-left: 800px;">
                   <a href="./MyProfile.php" style="text-decoration: none; color: black;">My Profile</a> 
                <img class="myprofile" src="./img/myprofile.JPG" alt="logo" style="padding: 5px;" height="60" width="60"></span>
            </h2>
        </div>
    </div>
    <div class="anime">
        <marquee behavior="" direction="" width="100%" scrolldelay="1sec">
            <p>Welcome To Panchayat Samiti, Gangapur</p>
        </marquee>
    </div>
    <div class="middle" style="display: flex;">
        <div class="col-sm-3 col-xs-12 notice">
            <div class="alert alert-warning text-center">
                <a href="#" data-toggle="modal" data-target="#PostBank">
                    <img src="./img/PostBank.jpg" alt="Post Bank" width="100%" />
                    <h4>Guidelines for Aadhaar linking to bank account</h4>
                </a>
            </div>
            <div class="panel">
                <div class="item item1"><img src="./img/bell.JPG" alt="Notice Icon"></i></div>
                <div class="item item2">
                    <h3></i>Notice</h3>
                </div>
            </div>
            <div class="box-link new-reg">
                <div class="help icon">
                    <img src="./img/call.JPG" alt="">
                </div>
                <div class="help help1">
                    <h4 style="color: black;">Helpline Number</h4>
                </div>
                <div class="box2">
                    <div class="help no"><a href="">00-000000000</a></div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xs-12">

            <div class="middle-panel panel-default">
                <!-- Wrapper for slides -->
                <div class="carousel-wrapper">
                    <span id="item-1"></span>
                    <span id="item-2"></span>
                    <div class="carousel-item item-1">
                        <a href="#item-1" class="arrow-prev arrow"></a>
                        <a href="#item-2" class="arrow-next arrow"></a>
                    </div>

                    <div class="carousel-item item-2">
                        <a href="#item-1" class="arrow-prev arrow"></a>
                        <a href="#item-1" class="arrow-next arrow"></a>
                    </div>

                </div>
            </div>
            <div class="instruction">
                <h2 style="text-align:center;">Instruction</h2>
                <div class="inst" style="margin: 10px; font-size:16px">
                <p> <li> Please ensure that your current mobile number is linked with your Aadhaar number.</li>
                <p><li>Enter your registered username Enter your password.</p></li>
                <p><li>Enter your confirm password and confirmed.</p></li>

                <p><li>Click on Log in button for login.</p></li>

                <p><li>If you forgot your password during registration, click on the "Forgot Password" button</p></li>
                </div>
            </div>
        </div>
        <div class="clickproceed">
            <label for=""><img style="height: 20px; width: 20px; margin-right: 7px;" src="./img/down-arrows.JPG" alt="">Click Below Link To
                Proceed</label>
            <div class="box">
                <div class="box-1 boxes"> <a href="./Tree-Planting.php">Tree Planting</a></div>
                <div class="box-2 boxes"><a href="./Irrigation.php">Individual Irrigation</a></div>
                <div class="box-3 boxes"><a href="./Individual-farms.php">Individual Farms</a></div>
                <div class="box-4 boxes"><a href="">Herd For Animals</a></div>
            </div>

        </div>
    </div>
    <section id="contact">
        <div class="section-content">
            <h1 class="section-header"> <label class="get-in" style="font-size: 30px; color: #fff;"> Get in
                </label><span class="content-header wow fadeIn " data-wow-delay="0.2s" data-wow-duration="2s"> Touch
                    with
                    us</span></h1>
            <h3> Feel Free To Contact Us</h3>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="well well-sm">
                        <form>
                            <div class="row about">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">
                                            Name</label>
                                        <input type="text" class="form-control" id="name" placeholder="Enter name"
                                            required="required" />
                                    </div>
                                    <div class="form-group">
                                        <label for="email">
                                            Email Address</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><span
                                                    class="glyphicon glyphicon-envelope"></span>
                                            </span>
                                            <input type="email" class="form-control" id="email"
                                                placeholder="Enter email" required="required" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="subject">
                                            Subject</label>
                                        <select id="subject" name="subject" class="form-control" required="required">
                                            <option value="na" selected="">Choose One:</option>
                                            <option value="service">General Customer Service</option>
                                            <option value="suggestions">Suggestions</option>
                                            <option value="product">Product Support</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">
                                            Message</label>
                                        <textarea name="message" id="message" class="form-control" rows="9" cols="25"
                                            required="required" placeholder="Message"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary pull-right" id="btnContactUs"
                                        style="font-size: 20px;">
                                        Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-4">
                    <form class="address" style="font-size: 18px; color: #fff;">
                        <legend style="font-size: 22px; color: #fff;"><span
                                class="glyphicon glyphicon-globe"></span> Our office</legend>
                        <address>
                            <strong>P224+7WF,</strong><br>
                            Local Government Office, <br>
                            Nutan Colony,<br>
                            Gangapur Maharashtra.<br>
                            <abbr title="Phone">
                                Pin : </abbr>
                            431 109
                        </address>
                        <address>
                            <strong>Full Name</strong><br>
                            <a href="mailto:#">first.last@example.com</a>
                        </address>
                    </form>
                </div>
            </div>
        </div>
    </section>
    </header>

    <footer class="footer">
        <div class="col-md-12 text-center">
            <div class="copyright" style="margin: 30px; font-size: 18px;">
                <p>© <span>2022</span> <a href="#" class="transition">@Vaishnavi</a> All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>

</html>