<?php
include('conn_db.php');
include('session.php');
?>

<!DOCTYPE html>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
.header{
    box-sizing: border-box;
    text-align: center;
    margin: 10px;
}
</style>
<body>
    <header class="header">
        <nav>
            <h2>Gram-Vikas Yojna</h2>
        </nav>
        <p style="font-size: 16px;">
            You are now logged in. you can logout by clicking on signout link given below.
        </p>
    </header>
    <div id="center">
        <div id="contentbox">
            <div id="contentbox">
                <?php
                // echo $loggedin_id;
            $sql="SELECT * FROM registration where EmpName= '$loggedin_id'";
            $result=mysqli_query($conn,$sql);
            ?>
            <?php
            while($rows=mysqli_fetch_array($result)){
            ?>
                <div id="signup">
                    <div id="signup-st">
                        <form action="./execute.php" method="get" id="signin" id="reg">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad">
                                <div class="panel panel-info">
                                    <div class="panel-heading" style="height: 45px;">
                                        <h3 style="margin: 0px;">Welcome <?php echo $loggedin_session; ?>,
                                        </h3>
                                    </div>
                                    <div id="signup">
                                            <div id="reg-head" class="headrg" style="font-size: 18px; margin: 5px;">Your
                                                Profile</div>
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-md-3 col-lg-3 "> <img alt="User Pic" height="90" width="90" style="border-radius: 50px;"
                                                            src="./img/myprofile.JPG"
                                                            class="img-circle img-responsive"> </div>
                                                    <div class=" col-md-9 col-lg-9 ">
                                                        <table class="table table-user-information">
                                                            <tbody>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align: left;" id=tb-name>Reg
                                                                            id:</div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <!-- <?php echo $rows['mem_id']; ?>
                                                                     -->
                                                                     <?php echo "123"; ?>
                                                                     <!-- I hard coded this id because we don't have any id in our database -->
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>
                                                                            Username:</div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['EmpName']; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>Email:
                                                                        </div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['email']; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>
                                                                            Address:</div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['address']; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>City:
                                                                        </div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['city']; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>State:
                                                                        </div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['country']; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>
                                                                            Country:</div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['country']; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr id="lg-1">
                                                                    <td class="tl-1">
                                                                        <div style="text-align:left;" id=tb-name>Pin:
                                                                        </div>
                                                                    </td>
                                                                    <td class="tl-4">
                                                                        <?php echo $rows['pin']; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                        <a href="./logout.php" class="btn btn-primary">Logout</a>
                                                        <a href="./deleteac.php" class="btn btn-primary">Delete Account</a>
                                                        <a href="./userwel.php" class="btn btn-primary">Go to Home Page</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel-footer">
                                                <a data-original-title="Broadcast Message" data-toggle="tooltip"
                                                    type="button" class="btn btn-sm btn-primary"><i
                                                        class="glyphicon glyphicon-envelope"></i></a>
                                                <span class="pull-right">
                                                    <a href="edit.html" data-original-title="Edit this user"
                                                        data-toggle="tooltip" type="button"
                                                        class="btn btn-sm btn-warning"><i
                                                            class="glyphicon glyphicon-edit"></i></a>
                                                    <a data-original-title="Remove this user" data-toggle="tooltip"
                                                        type="button" class="btn btn-sm btn-danger"><i
                                                            class="glyphicon glyphicon-remove"></i></a>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            <?php
            }
            ?>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="copyright">
                        <p style="margin: 30px; font-size:16px">© <span>2022</span> <a href="#" class="transition">@Vaishnavi</a> All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>