<?php
$host= "localhost";
$username= "root";
$password = "";

$db_name = "project";

$conn = mysqli_connect($host, $username, $password, $db_name);

$query = "select email and password from registration";
$data = mysqli_query($conn , $query);

if($data){
    echo '<script>alert("Login successfully !")</script>';
}
else{
    echo '<script>alert("All fields are required")</script>';
}
?>