<?php
error_reporting(0);
?>


<style>
    *body {
        margin: 0%;
        font-family: 'open_sansregular', Arial, Helvetica, sans-serif;

    }

    .heading {
        color: #fff;
        height: 70px;
        width: 100%;
        background-color: rgb(36, 164, 36);
    }

    .topStrip ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .leftLink {
        float: left;
        list-style: none;
    }

    .rightLink {
        float: right;
        list-style: none;
        display: list-item;
        display: flex;
    }

    .flag {
        height: 24;
        width: 35;
        margin-right: 5px;
    }

    .topStrip {
        color: black;
        padding: 20px 20px;
        box-sizing: border-box;
        font-size: 15px;
        height: 80px;
        margin: 0%;
        background-color: rgb(235, 221, 247);
        border-left: 3px solid rgb(200, 151, 243);
        border-right: 3px solid rgb(200, 151, 243);
        border-top-right-radius: 10px;
        border-top-left-radius: 10px;
    }

    .topStrip li {
        float: left;
        position: relative;
        font-size: 23px;
    }

    .textResizeWrapper {
        margin-right: 10px;
    }

    .search {
        margin-right: 5px;
        list-style: none;
    }

    .searchBlock {
        line-height: 30px;
        border-radius: 10px;
    }

    .anime {
        box-sizing: border-box;
        margin: 10px;
        background-color: rgb(250, 183, 236);
        height: 50px;
        border-left: 5px solid rgb(182, 67, 157);
        border-right: 5px solid rgb(182, 67, 157);
        border-radius: 7px;
    }

    .anime p {
        margin: 10px;
        font-size: 20px;
    }
</style>
    <div class="heading" style="text-align: center;">
    <div class="logobar">
        <h2 style="margin:0%; padding: 10px;">
            <img src="./img/logo1.png" alt="logo" height="50" width="50">
            Gram-Vikas Yojna
        </h2>
    </div>
</div>
<div class="anime">
    <marquee behavior="" direction="" width="100%" scrolldelay="1sec">
        <p>Welcome To Panchayat Samiti, Gangapur</p>
    </marquee>
</div>

<!--
-----

-->