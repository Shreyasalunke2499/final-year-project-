<footer>
    <div class="container" style=" background-color:white; text-align:center">
        <div class="row">
            <div class="col-md-12 footer">
                &copy; 2022 Digital Gram Vikas Vojana | By : <a href="https://www.linkedin.com/in/ganeshabansa" target="_blank">Ganesha Bansa</a><i class="fa fa-linkedin btn-linkedin" ></i>
            </div>
        </div>
    </div>
</footer>