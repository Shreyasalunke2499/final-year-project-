<style>
.nav{
    font-size: 18px;
    
}
</style>

<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 nav">
                <div class="navbar-collapse collapse ">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">
                        <li><a href="scheme.php">All Schemes</a></li>
                        <li><a href="user-info.php">User Details</a></li>
                        <!-- <li><a href="department.php">Department</a></li> -->
                        <!-- <li><a href="course.php">Course</a></li> -->
                        <!-- <li><a href="student-registration.php">Registration</a></li> -->
                        <!-- <li><a href="manage-students.php">Manage Students</a></li> -->
                        <!-- <li><a href="enroll-history.php">Enroll History</a></li> -->
                        <li><a href="change-password.php">Change Admin Password</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
