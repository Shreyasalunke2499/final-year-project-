<?php 

// Fetch ALL The Documents
if ( isset($_FILES["farm_file"]) ) {
    $benfile = $_FILES["farm_file"]["name"];
    $temp = $_FILES["farm_file"]["tmp_name"];
    
    $pathOfFarm = "doc/".$benfile;
    move_uploaded_file($temp, $pathOfFarm);
    // echo "<br>".$pathOfBonafied;
}
if ( isset($_FILES["selffarm_file"]) ) {
    $benfile = $_FILES["selffarm_file"]["name"];
    $temp = $_FILES["selffarm_file"]["tmp_name"];
    
    $pathOfSelffarm = "doc/".$benfile;
    move_uploaded_file($temp,$pathOfSelffarm);
    // echo "<br>".$pathOfAddhar;
}
 
if ( isset($_FILES["adhar_file"]) ) {
    $benfile = $_FILES["adhar_file"]["name"];
    $temp = $_FILES["adhar_file"]["tmp_name"];
    
    $pathOfAddhar = "doc/".$benfile;
    move_uploaded_file($temp,$pathOfAddhar);
    // echo "<br>".$pathOfCastCertificate;
}

if ( isset($_FILES["dom_file"]) ) {
    $benfile = $_FILES["dom_file"]["name"];
    $temp = $_FILES["dom_file"]["tmp_name"];
    
    $pathOfDomicile = "doc/".$benfile;
    move_uploaded_file($temp,$pathOfDomicile);
    // echo "<br>".$pathOfDomicile;
}


if ( isset($_POST['name']) ) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $pin = $_POST['pin'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];

    $village = $_POST['village'];
    $groupno = $_POST['groupno']; 
    $area= $_POST['area'];
    //$in = $_POST['inline'];
    $adharno = $_POST['adharno'];
    $username= $_POST['username'];
    $certno = $_POST['certno'];
    

//query = INSERT INTO irrigation ('name','email','phone','address','city','pin','gender','age','village','groupno','area','farm_file','selffarm_file','adharno','adhar_file','username','certno','dom_file') VALUES ($name,$email,$phone,$address,$city,$pin,$gender,$age,$village,$groupno,$area,$pathOfFarm, $pathOfSelffarm ,$adharno, $pathOfSelffarm,$username,$certno ,$pathOfDomicile )
    //echo "$village<br>";
    //echo "$gname<br>";
    //echo "$area<br>";
    //echo "$name<br>";
    //echo "$em<br>";
    //echo "$phone<br>";
    // echo "$addr<br>";
    // echo "$c<br>";
    // echo "$pi<br>";
    // echo "$s<br>";
    // echo "$gen<br>";
    // echo "$ag<br>";
    include("conn_db.php");
    error_reporting(0);
    
    //$query = "insert into individual_farms (Name, email, phone, address, city, pin, gender, age, village, gname, area,  benified_file, adhar_no, adhar_file, username, certno, cast_certfile, uname, cr_no, domicile_cert, accno, ifsc, branch, passbook_file) values ('$name', '$em', '$phone', '$addr', '$c','$pi', '$gen', '$ag', '$vl', '$gn', '$ar', '$pathOfBonafied', '$adhar' ,'$pathOfAddhar', '$username', '$cno' ,'$pathOfCastCertificate' , '$uname', '$crno', '$pathOfDomicile', '$acno', '$if', '$br', '$pathOfPassbook')";
                                                                                                                                                                                                                                                                                        
    //$query = "insert into irrigation (name, email, phone, address, city, pin, gender, age, village, groupno, area,  farm_file, selffarm_file,  adharno, adhar_file, username, certno, dom_file) values ('$name', '$em', '$phone', '$addr', '$c','$pi', '$gen', '$ag', '$vl', '$gn', '$ar', '$pathOfFarm','$pathOfselffarms', '$adhar'  ,'$pathOfAddhar' ,username', '$cno' , '$pathOfDomicile')";
    // $query = "insert into individual_farms (Name, email, phone, address, city, pin, gender, age) values ('$name','$em','$phone', '$addr', '$c','$pi', '$gen', '$ag')";
    $query = "insert into irrigation (name, email, phone, address, city ,pin , gender, age , village , groupno , area, farm_file, selffarm_file, adharno , adhar_file, username , certno ,dom_file ) VALUES ('$name','$email','$phone','$address','$city','$pin','$gender','$age','$village','$groupno','$area','$pathOfFarm', '$pathOfSelffarm' ,'$adharno', '$pathOfSelffarm','$username','$certno' ,'$pathOfDomicile' )";
    $data = mysqli_query($conn , $query);
    if($data){
        header("location: successfullyAppiled.php");
    }
    else{
        header("location: notApplied.php");
    }
}

// Check Post Data
//echo '<xmp>';
//print_r($_POST);
//echo '</xmp>';

// Check File Data
//echo '<xmp>';
//print_r($_FILES);
//echo '</xmp>';

        
?>