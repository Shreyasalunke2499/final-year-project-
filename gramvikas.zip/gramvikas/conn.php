<?php

$ename=$_GET['Name'];
$em= $_GET['Email'];
$pass= $_GET['Password'];
$repass= $_GET['Repassword'];
$addr= $_GET['Address'];
$c=$_GET['City'];
$s= $_GET['State'];
$count=$_GET['Country'];
$pi= $_GET['Pin'];

echo "$ename";
echo "$em";
echo "$pass";
echo "$repass";
echo "$addr";
echo "$c";
echo "$s";
echo "$count";
echo "$pi";

$host= "localhost";
$username= "root";
$password = "";

$db_name = "registration";

$conn = mysqli_connect($host, $username, $password, $db_name);
$query = "insert into registration values ('$ename','$em','$pass','$repass', '$addr', '$c', '$s', '$count', '$pi')";
$data = mysqli_query($conn , $query);

if($data){
  echo '<script>alert("Data inserted successfully !")</script>';
}
else{
  echo '<script>alert("All fields are required")</script>';
}

?>