<?php
include("conn_db.php");
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$password=mysqli_real_escape_string($conn,$_POST['password']);
    // $result = mysqli_query($conn,"SELECT * FROM registration");
	// $c_rows = mysqli_num_rows($result);
	// if ($c_rows!=$email) {
	// 	header("location: reg.php?remark_login=failed");
	// }
    $sql="SELECT email FROM registration WHERE email='$email' and password='$password'";
	$result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($result);
	$count=mysqli_num_rows($result);
	if($count==1) {
		$_SESSION['login_user']=$email;
		header("location: MyProfile.php");
		// echo "seccess login";
	}else{
		echo "You Have Entered Incorrect Information";
	}
}else {
	echo "error";
}
?>