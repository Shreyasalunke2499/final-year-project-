<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Individual Irrigation Scheme</title>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
  .header {
    box-sizing: border-box;
    border: 1px solid rgb(38, 122, 39);
    background-color: rgb(68, 182, 56);
    text-align: center;
    margin-top: 3px;
    position: sticky;
    top: 1px;
  }

  .yojna-name {
    display: flex;
    margin-left: 20px;
    margin-top: 5px;
  }

  .yojna-name h2 {
    padding: 10px;
  }

  .yojna-name ul {
    text-align: center;
  }

  .header img {
    width: 60px;
    height: 60px;
    margin: 5px;
  }

  .navbar {
    position: sticky;
    height: 60px;
    width: 550px;
    text-align: center;
    box-sizing: border-box;
    margin-left: 200px;
    background-color: rgb(62, 146, 56);
  }

  .nav {
    list-style: none;
    margin-bottom: 5px;
  }

  .nav-link {
    color: white;
    text-decoration: none;
    font-size: 22px;
    margin-bottom: 10px;
    align-content: center;

  }

  .anime {
    box-sizing: border-box;
    margin: 20px;
    background-color: rgb(250, 183, 236);
    height: 55px;
    border-left: 5px solid rgb(182, 67, 157);
    border-right: 5px solid rgb(182, 67, 157);
    border-radius: 10px;
  }

  .anime p {
    margin: 10px;
    font-size: 20px;
  }

  .section {
    justify-content: center;
    margin-top: 15px;
  }

  .contain {
    border: 1px solid black;
    width: 800px;
    height: 460px;
    margin: auto;

  }

  .scheme-head {
    background-color: rgb(80, 199, 98);
    text-align: center;
    height: 50px;
    margin: 5px;
  }

  .doc-head {
    margin: 15px;
    margin-top: 20px;
  }

  .doc-list li {
    font-size: 18px;
    line-height: 35px;
  }

  .doc-list ol {
    margin: 10px;
  }

  .checkbox {
    margin: 20px;
    font-size: 18px;
  }

  .buttons {
    margin: 30px;
  }

  .buttons a {
    font-size: 18px;
  }

  .submit {
    float: right;
  }

  .footer {
    margin: 5px;
    margin-top: 20px;
  }
</style>

<body>
  <header class="header">
    <div class="yojna-name">
      <img src="./img/logo1.png" alt="Logo">
      <h2 style="font-family: 'Times New Roman', Times, serif;">Gram Vikas Yojna</h2>

      <div class="navbar">
        <section class="nav">
        <a class="nav-link" href="#"></a>
          <a class="nav-link active" aria-current="page" href="./welcome.php">Home</a>
          <a class="nav-link" href="#"></a>
          <a class="nav-link" href="./welcome.php">About Us</a>
        </section>
      </div>
    </div>
  </header>
  <div class="anime">
    <marquee behavior="" direction="" width="100%" scrolldelay="1sec">
      <p>Mahatma Gandhi National Rular Employment Guarantee Scheme(Individual Irrigation)</p>
    </marquee>
  </div>
  <div class="section">
    <div class="contain">
      <div class="scheme-head">
        <h2 class="scheme-heading">Individual Irrigation Scheme</h2>
      </div>
      <div class="doc-head">
        <h5>List of Required Documents : </h5>
        <hr>
      </div>
      <div class="doc-list">
        <ol>
          <li>Aadhar Card</li>
          <li>Domicile Certificate</li>
          <li>Self Declaration</li>
          <li>Certificate of no Well and no Well within 500 feet</li>
        </ol>
      </div>

      <div class="checkbox">
        <input type="checkbox" name="check-button" id="">
        I agree for the scheme and I have the real documents which are mentioned as above. I will attach
        all necessary documents as per the propsal.
      </div>

      <div class="buttons">
        <a href="./Welcome.php" class="back btn btn-primary"> Back</a>
        <a href="./Irrigation2.php" class=" submit btn btn-success"> Continue</a>

      </div>
    </div>
  </div>
  <footer class="footer">
    <hr>
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <div class="copyright">
            <p>© <span>2022</span> <a href="#" class="transition">@Vaishnavi</a> All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  </footer>
</body>

</html>